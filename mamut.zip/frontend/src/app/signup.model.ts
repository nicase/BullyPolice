export class Signup {
  email: String
  firstName: String
  lastName: String
  password: String
  password2: String
}
