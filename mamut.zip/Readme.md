# Backend
- nvm use
- npm install
- npm run fixtures
- npm run dev

# Frontend
- nvm use
- npm install
- npm start

# Python
- python3 main.py