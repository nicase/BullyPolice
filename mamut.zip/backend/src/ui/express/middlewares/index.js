const checkUserAuthenticated = require('./checkUserAuthenticated');

module.exports = {
  checkUserAuthenticated,
};
